﻿#Check if "Evidence-Of-Execution" exists.
    $folderPath = "C:\ForensicMiner\MyEvidence\01-Evidence-Of-Execution"
    if (Test-Path $folderPath) {
      Remove-Item $folderPath -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
    }

    #Create the "Evidence-Of-Execution" folder.
    New-Item -ItemType Directory -Force -Path "C:\ForensicMiner\MyEvidence\01-Evidence-Of-Execution" | Out-Null

    $sysPath = Join-Path $env:WinDir 'system32\drivers\bam.sys'
    if (Test-Path $sysPath) {
      #Variable for the First foreach
      $ExcludeList1 = 'S-1-5-90.*','S-1-5-18'
      $SIDS = Get-Item -Path "HKLM:\SYSTEM\CurrentControlSet\Services\bam\State\UserSettings\*" |
      Select-Object -ExpandProperty PSChildName |
      Where-Object { $_ -notmatch ($ExcludeList1 -join '|') }

      #Start of the first foreach - SIDS
      foreach ($SID in $SIDS) {
        #For the text file name
        $TxtUsrNam = Get-LocalUser -SID $SID -ErrorAction SilentlyContinue

        $OutFile = "C:\ForensicMiner\MyEvidence\01-Evidence-Of-Execution\$($TxtUsrNam) $($SID).txt"
        $registryPath = "HKLM:\SYSTEM\CurrentControlSet\Services\bam\State\UserSettings\$SID"

        # Get the values under the registry key
        $values = Get-ItemProperty -Path $registryPath | Select-Object -Property *

        # Create an empty array to store the sorted results
        $sortedResults = @()

        # Loop through the values and add them to the array
        foreach ($valueName in $values.PSObject.Properties.Name) {
          if ($valueName -like '\Device\*') {
            $valueData = [BitConverter]::ToInt64($values.$valueName,0)
            $result = $valueName -replace '^\\Device\\HarddiskVolume\d+\\'
            $timestamp = if ($valueData -ne $null) {
              [datetime]::FromFileTime($valueData)
            } else {
              "Not available"
            }

            # Create an object with the properties
            $sortedResults += [pscustomobject]@{
              Software = $result
              Timestamp = $timestamp
            }
          }
        }

        # Sort the results based on the 'Timestamp' property in descending order
        $sortedResults = $sortedResults | Sort-Object -Property Timestamp -Descending

        # Display the sorted results
        Write-Output "┌---------------------------------------------------┐" | Tee-Object -FilePath $OutFile -Append
        Write-Output "├USER: $(Get-LocalUser -SID $SID -ErrorAction SilentlyContinue)" | Tee-Object -FilePath $OutFile -Append
        Write-Output "├SID : $SID" | Tee-Object -FilePath $OutFile -Append
        Write-Output "|" | Tee-Object -FilePath $OutFile -Append

        foreach ($result in $sortedResults) {
          Write-Output "├Software:  $($result.Software)" | Tee-Object -FilePath $OutFile -Append
          Write-Output "├Timestamp: $($result.Timestamp)" | Tee-Object -FilePath $OutFile -Append
          Write-Output "|" | Tee-Object -FilePath $OutFile -Append
        }

        Write-Output "└-> End-of-List" | Tee-Object -FilePath $OutFile -Append
        Write-Output ""
      }

      Write-Output ""
      Write-Output "+-------------------------------------------------------------+"
      Write-Output "|The record of this forensic evidence is saved on this machine|"
      Write-Output "+-------------------------------------------------------------+"
      Write-Output '|Path - "C:\ForensicMiner\MyEvidence\01-Evidence-Of-Execution"|'
      Write-Output "+-------------------------------------------------------------+"
      Write-Output ""
    }
    else {
      Write-Output "bam.sys file not found. Script can't run without it." | Tee-Object -FilePath $OutFile -Append


    }