    #Create the "C:\ForensicMiner\MyZIP" folder.
    New-Item -ItemType Directory -Force -Path C:\ForensicMiner\MyZIP | Out-Null

    $folderPath = "C:\ForensicMiner"
    $Hostname = hostname
    $DPath = "C:\ForensicMiner\MyZIP\ForensicMiner-$Hostname.zip"

    if ((Get-ChildItem -Path $folderPath | Measure-Object).Count -eq 0) {
      # Empty folder - Execute 'else' block
      Write-Output "Unfortunately, your forensic evidence could not be successfully zipped."
      Write-Output "Did you even collect any forensic evidence?"
    }
    else {
      # Non-empty folder - Execute 'if' block
      if (Test-Path -Path $DPath) {
        Remove-Item -Path $DPath -Force
        Write-Output "Existing zip file 'ForensicMiner-$Hostname.zip' deleted, creating a new one."
        Write-Output ""
      }

      Compress-Archive -Path $folderPath -DestinationPath $DPath -Force
      Write-Output "Your forensic evidence has been successfully zipped."
      Write-Output "Below is the list of the forensic evidence you have collected:"
      Write-Output "+------------------------------------------------------------+"
      Write-Output ""

      #Show list of files.
      $files = Get-ChildItem -Path "$folderPath\*"
      $files | ForEach-Object {
        Write-Output ("Creation Time: {0}, Name: {1}" -f $_.CreationTime,$_.Name)
      }


      Write-Output ""
      Write-Output "+------------------------------------------------------------------+"
      Write-Output "| The record of this forensic evidence is saved on this machine"
      Write-Output "+------------------------------------------------------------------+"
      Write-Output "| Path - $DPath"
      Write-Output "+------------------------------------------------------------------+"
    }