$FolderRemove = "C:\ForensicMiner\"

if (Test-Path -Path $FolderRemove) {
  Write-Output "The following files have been successfully purged from this machine:"
  Write-Output "+------------------------------------------------------------------+"
  $files = Get-ChildItem -Path "$FolderRemove\*"
  $filesToDelete = @()

  foreach ($file in $files) {
    $fileInfo = [pscustomobject]@{
      CreationTime = $file.CreationTime
      Name = $file.Name
    }
    $filesToDelete += $fileInfo
  }

  foreach ($fileInfo in $filesToDelete) {
    Write-Output ("Creation Time: {0}, Name: {1}" -f $fileInfo.CreationTime,$fileInfo.Name)
    Remove-Item -Path "$FolderRemove\$($fileInfo.Name)" -ErrorAction SilentlyContinue -Force -Recurse
  }

}

# related vareable path
$FMextractor = "C:\FM-Extractor.ps1"
$FMpackage = "C:\FM-Package.zip"

# deleting C:\FM-Extractor.ps1
if (Test-Path -Path $FMextractor -PathType Leaf) {
Remove-Item -Path $FMextractor -ErrorAction SilentlyContinue -Force -Recurse
}
else {
}

# deleting C:\FM-Package.ps1
if (Test-Path -Path $FMpackage -PathType Leaf) {
Remove-Item -Path $FMpackage -ErrorAction SilentlyContinue -Force -Recurse
}
else {
}

Write-Output ""

cd ..

# Double delete verify
Start-Sleep -Seconds 2.5
Remove-Item -Path "C:\ForensicMiner" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
Remove-Item -Path "C:\FM-Package.zip" -Force -Recurse -ErrorAction SilentlyContinue | Out-Null
